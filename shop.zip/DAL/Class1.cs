﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class Class1
    {

    }

    public class ClsDataLayer
    {
        SqlConnection Sqlconn = new SqlConnection("Data Source=desktop-3l7k4hv\\shrisql;Initial Catalog=3tier;User ID=sa;Password=Shri@123");
        public void InsertData(string _name, string _city, string _email)
        {
            SqlDataAdapter SQLadp = new SqlDataAdapter("Insert into Usermst values ('" + _name + "','" + _city + "','" + _email + "')", Sqlconn);
            DataTable DT = new DataTable();
            SQLadp.Fill(DT);
        }
        public object SelectData()
        {
            SqlDataAdapter SQLadp = new SqlDataAdapter("select * from Usermst", Sqlconn);
            DataTable DT = new DataTable();
            SQLadp.Fill(DT);
            return DT;
        }
    }
}